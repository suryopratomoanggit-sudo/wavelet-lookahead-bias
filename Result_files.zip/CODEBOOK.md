# Codebook for Result_files

All files are comma-separated (CSV). They hold the results produced by `Code_analysis_notebook.ipynb`. Column names and labels were translated into English. The numbers are unchanged.

**Schemes**
- **A**: raw log price, with no denoising.
- **B**: full-sample wavelet-denoised log price. This is the common practice and it has look-ahead bias.
- **C**: causal (rolling-window) wavelet denoising, which uses no future data.

**Accuracy**
- Accuracy is the percentage of test days with a correctly predicted direction of the next-day return.
- Days with zero actual return are excluded.

**Tests**
- All p-values are two-sided unless stated otherwise.
- **McNemar test**: compares direction errors between two schemes on the same days.
  - *b* is the number of days the first scheme is right and the second wrong.
  - *c* is the number of days the reverse holds.
- **Diebold–Mariano test**: compares squared forecast errors.

## File names

The notebook writes these files under Indonesian names. The table maps each English name to the original name.

| English file name | Original notebook output | Article |
| --- | --- | --- |
| `walkforward_accuracy.csv` | `wf_akurasi.csv` | Tables 2–3 |
| `walkforward_tests.csv` | `wf_uji.csv` | Tables 2–3 |
| `exact_test_statistics.csv` | `statistik_lengkap.csv` | Tables 2–3 |
| `robustness_results.csv` | `uji_ketahanan.csv` | Figures 1–2 |
| `sample_screening.csv` | `seleksi_sampel.csv` | Table S1 |
| `lq45_results.csv` | `hasil_lq45.csv` | Table 1, Figure 3, Table S2 |
| `lstm_results.csv` | `hasil_lstm.csv` | Table 4 |

## walkforward_accuracy.csv
Rows are measures and columns are the case stocks (EMTK, ARTO, BUKA, BBCA). Cells show accuracy in % with the exact binomial p-value against 50% in parentheses.

| Row | Meaning |
| --- | --- |
| Scheme A/B/C accuracy (%) | Walk-forward direction accuracy of each scheme |
| Naive trend baseline accuracy (%) | Always predicts the majority direction of the training data |
| Naive persistence baseline accuracy (%) | Predicts the same direction as the previous day |
| Share of down days in test period (%) | Percentage of test days with a negative return |

## walkforward_tests.csv
Rows are tests and columns are the case stocks. Cells are p-values, except the last row.

| Row | Meaning |
| --- | --- |
| McNemar p, B vs C (direction) | Exact McNemar test, scheme B vs C |
| McNemar p, C vs A (direction) | Exact McNemar test, scheme C vs A |
| Diebold-Mariano p, B vs C (squared error) | Diebold–Mariano test on squared errors, B vs C |
| Diebold-Mariano p, C vs A (squared error) | Diebold–Mariano test on squared errors, C vs A |
| Number of test days | Days in the walk-forward test period |

## exact_test_statistics.csv
| Column | Meaning |
| --- | --- |
| Stock | IDX ticker |
| Test | Accuracy of a scheme or baseline, or the McNemar or Diebold–Mariano comparison |
| Statistic | Correct/total = accuracy for accuracy rows; b and c for McNemar; DM statistic for Diebold–Mariano |
| p (exact) | Exact binomial p-value (accuracy rows against 50%, McNemar rows) or Diebold–Mariano p-value |

## robustness_results.csv
32 combinations of configuration (8) and stock (4).

| Column | Meaning |
| --- | --- |
| Configuration | Main (db4 wavelet, level 4, window 256, linear regression); one setting changed at a time: Wavelet haar, Wavelet sym8, Level 3, Level 5, Window 128, Window 512, Random forest model |
| Stock | Case stock |
| Accuracy A, B, C | Direction accuracy (%) of each scheme |
| B-C, C-A | Accuracy difference in percentage points |
| p B vs C, p C vs A | Exact McNemar p-values |

## sample_screening.csv
47 candidate stocks (LQ45 constituents plus ARTO and BUKA).

| Column | Meaning |
| --- | --- |
| Stock | IDX ticker |
| Trading days | Number of daily observations |
| First date | First date with data |
| Flat days (%) | Share of days with an unchanged closing price |
| Zero-volume days | Number of days with zero volume |
| Days at or below IDR 50 | Number of days with a closing price at or below the IDX floor of IDR 50 |
| Jumps above 35% | Number of absolute daily changes above 35% |
| Decision | Included, or Excluded with the screening rule that failed |

## lq45_results.csv
41 stocks that passed screening.

| Column | Meaning |
| --- | --- |
| Stock | IDX ticker |
| Test days | Number of test days |
| Accuracy A, B, C | Direction accuracy (%) of each scheme |
| Naive trend | Accuracy (%) of the naive trend baseline |
| B-C, C-A | Accuracy difference in percentage points |
| b BC, c BC, p BC | McNemar counts and exact p-value, B vs C |
| b CA, c CA, p CA | McNemar counts and exact p-value, C vs A |

## lstm_results.csv
LSTM forecaster on the four case stocks.

| Column | Meaning |
| --- | --- |
| Stock | Case stock |
| Test days | Number of test days |
| Accuracy A, B, C | Direction accuracy (%) of each scheme |
| B-C, C-A | Accuracy difference in percentage points |
| b/c BC, b/c CA | McNemar counts b/c |
| p BC, p CA | Exact McNemar p-values |
